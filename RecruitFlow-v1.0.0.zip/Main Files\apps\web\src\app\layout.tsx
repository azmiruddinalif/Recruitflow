import type { Metadata } from 'next';
import '@/styles/globals.css';
import { AppProviders } from './providers';

export const metadata: Metadata = {
  title: 'RecruitFlow — Enterprise AI Recruitment & Applicant Tracking System',
  description:
    'Multi-tenant B2B AI Recruitment SaaS platform with structured resume parsing, explainable candidate matching, Kanban pipelines, and interview scorecards.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full bg-[#F8FAFC] text-[#0F172A] antialiased">
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}
